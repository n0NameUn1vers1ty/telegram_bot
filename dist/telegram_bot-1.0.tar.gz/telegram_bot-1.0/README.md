##Telegram Bot 
**A bot that parses news channels and sends current news**

*1. install 'dist'* **(setup Project)**
*2. pip install -r requirements.txt* **(dependency)**