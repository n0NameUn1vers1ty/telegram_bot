##Telegram Bot 
**A bot that parses news channels and sends current news**