import telebot

import Bot

bot = telebot.TeleBot(Bot.config.TOKEN)


@bot.message_handler(content_types=['text'])
def lala(message):
    bot.send_message(message.chat.id, message.text)


# RUN
bot.polling(none_stop=True)
