print('__init__ package Bot')

from .config import *
